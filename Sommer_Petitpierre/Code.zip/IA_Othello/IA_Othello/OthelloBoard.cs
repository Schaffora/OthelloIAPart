﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Numerics;

namespace OthelloIA2
{ 
    public class OthelloBoard : IPlayable.IPlayable
    {

        Random rnd;
        private List<Case> board;
        private Player white;
        private Player black;

        private Dictionary<Case, bool> playableMoves;

        //Player constants
        public static readonly int PLAYER_WHITE = 0;
        public static readonly int PLAYER_BLACK = 1;

        //Movement constants
        public static readonly Vector2 CASE_TOP = new Vector2(0, -1);
        public static readonly Vector2 CASE_TOPRIGHT = new Vector2(1, -1);
        public static readonly Vector2 CASE_RIGHT = new Vector2(1, 0);
        public static readonly Vector2 CASE_BOTTOMRIGHT = new Vector2(1, 1);
        public static readonly Vector2 CASE_BOTTOM = new Vector2(0, 1);
        public static readonly Vector2 CASE_BOTTOMLEFT = new Vector2(-1, 1);
        public static readonly Vector2 CASE_LEFT = new Vector2(-1, 0);
        public static readonly Vector2 CASE_TOPLEFT = new Vector2(-1, -1);

        //AI constants
        public static readonly int[,] BASE_SCORES = { 
                                                        { 10000, -3000, 1000, 800, 800, 1000, -3000, 10000 }, 
                                                        { -3000, -5000, -450, -500, -500, -450, -5000, -3000 }, 
                                                        { 1000, -450, 30, 10, 10, 30, -450, 1000 },
                                                        { 800, -500, 10, 50, 50, 10, -500, 800 },
                                                        { 800, -500, 10, 50, 50, 10, -500, 800 },
                                                        { 1000, -450, 30, 10, 10, 30, -450, 1000 },
                                                        { -3000, -5000, -450, -500, -500, -450, -5000, -3000 },
                                                        { 10000, -3000, 1000, 800, 800, 1000, -3000, 10000 },
                                                    };
        public static readonly int[] VH_FACTOR = { 10, 3, 2, 2, 2, 2, 3, 10 };
        public static readonly int[,] DIAG_FACTOR_1 = {
                                                        { 6, 5, 4, 3, 3, 1, 1, 1 },
                                                        { 5, 6, 5, 4, 3, 3, 1, 1 },
                                                        { 4, 5, 6, 5, 4, 3, 3, 1 },
                                                        { 3, 4, 5, 6, 5, 4, 3, 3 },
                                                        { 3, 3, 4, 5, 6, 5, 4, 3 },
                                                        { 1, 3, 3, 4, 5, 6, 5, 4 },
                                                        { 1, 1, 3, 3, 4, 5, 6, 5 },
                                                        { 1, 1, 1, 3, 3, 4, 5, 6 }
        };
        public static readonly int[,] DIAG_FACTOR_2 = {
                                                        { 1, 1, 1, 3, 3, 4, 5, 6 },
                                                        { 1, 1, 3, 3, 4, 5, 6, 5 },
                                                        { 1, 3, 3, 4, 5, 6, 5, 4 },
                                                        { 3, 3, 4, 5, 6, 5, 4, 3 },
                                                        { 3, 4, 5, 6, 5, 4, 3, 3 },
                                                        { 4, 5, 6, 5, 4, 3, 3, 1 },
                                                        { 5, 6, 5, 4, 3, 3, 1, 1 },
                                                        { 6, 5, 4, 3, 3, 1, 1, 1 },
        };


        private int playerTurn = PLAYER_BLACK;

        /************************************************
         *                                              * 
         *                 CONSTRUCTOR                  *
         *                                              *
         ************************************************/

        public OthelloBoard()
        {
            white = new Player(false);
            black = new Player(true);
            playableMoves = new Dictionary<Case, bool>();
            resetBoard();
            gameInit();
            rnd = new Random();
        }

        /************************************************
         *                                              * 
         *             INTERFACE FUNCTIONS              *
         *                                              *
         ************************************************/

        public int GetBlackScore()
        {
            return getNbOwnedCases(PLAYER_BLACK);
        }

        public int[,] GetBoard()
        {
            int[,] board = new int[8, 8];
            foreach(Case c in this.board)
            {
                board[CharPosToInt(c.Column), c.Row-1] = c.Owner == null ? -1 : c.Owner.PlayerColor == PLAYER_WHITE ? 0 : 1;
            }
            return board;
        }

        public string GetName()
        {
            return "2: Sommer_Petitpierre";
        }

        
        public Tuple<int, int> GetNextMove(int[,] game, int level, bool whiteTurn)
        {
            resetBoard();
            for(int i = 0; i<8; i++)
            {
                for(int j = 0; j<8; j++)
                {
                    getCase((char)(i + 97), j+1).Owner = game[i, j] == -1 ? null : game[i, j] == 0 ? white : black;
                }
            }

            playerTurn = whiteTurn ? PLAYER_WHITE : PLAYER_BLACK;
            setPlayableMoves();
            int nbPos = 0;
            foreach(bool isPlayable in playableMoves.Values)
            {
                if (isPlayable)
                {
                    nbPos++;
                }
            }

            if (nbPos == 0)
            {
                return new Tuple<int, int>(-1, -1);
            }

            Tuple<int, Case> retval = AlphaBeta(level, -1, 0);

            return new Tuple<int, int>(CharPosToInt(retval.Item2.Column), retval.Item2.Row-1);
        }

        public int GetWhiteScore()
        {
            return getNbOwnedCases(PLAYER_WHITE);
        }

        public bool IsPlayable(int column, int line, bool isWhite)
        {
            this.playerTurn = isWhite ? PLAYER_WHITE : PLAYER_BLACK;
            Case playedCase = getCase((char)(column + 97), line);
            return isPlayableCustom(playedCase);
        }

        //Alpha-Beta: apply function
        public bool PlayMove(int column, int line, bool isWhite)
        {
            this.playerTurn = isWhite ? PLAYER_WHITE : PLAYER_BLACK;
            return playMoveCustom((char)(column + 97), line+1);
        }

        /************************************************
         *                                              * 
         *              CUSTOM FUNCTIONS                *
         *                                              *
         ************************************************/

        private void gameInit()
        {
            getCase('d', 4).Owner = white;
            getCase('e', 5).Owner = white;
            getCase('e', 4).Owner = black;
            getCase('d', 5).Owner = black;
            setPlayableMoves();
        }

        private Case getCase(char col, int row)
        {
            foreach (Case c in board)
            {
                if (c.Column == col && c.Row == row)
                {
                    return c;
                }
            }
            return null;
        }

        // Alpha-Beta: ops function
        public void setPlayableMoves()
        {
            playableMoves.Clear();
            foreach (Case actCase in board)
            {
                playableMoves.Add(actCase, isPlayableCustom(actCase));
            }
        }

        public bool isPlayableCustom(Case c)
        {
            if (c.Owner != null) //Case occupée
            {
                return false;
            }
            bool isPlayable = false;
            Case[] adjacentCase = getAdjacent(c);
            int otherPlayer = getOtherPlayer();
            foreach (Case cc in adjacentCase)
            {
                if (cc != null && cc.Owner != null)
                {
                    if (cc.Owner.PlayerColor == otherPlayer)
                    {
                        Vector2 direction = new Vector2(cc.Column - c.Column, cc.Row - c.Row);
                        Case nextCase = getAdjacentWithDirection(cc, direction);
                        while (nextCase != null && nextCase.Owner != null)
                        {
                            if (nextCase.Owner.PlayerColor == playerTurn || nextCase.Owner == null)
                            {
                                break;
                            }
                            nextCase = getAdjacentWithDirection(nextCase, direction);

                        }
                        if (nextCase != null && nextCase.Owner != null && nextCase.Owner.PlayerColor == playerTurn)
                        {
                            isPlayable = true;
                        }
                    }
                }
            }
            return isPlayable;
        }

        public Case[] getAdjacent(Case c)
        {
            return new Case[] {getAdjacentWithDirection(c, CASE_TOP), getAdjacentWithDirection(c, CASE_TOPRIGHT),
                                getAdjacentWithDirection(c, CASE_RIGHT) , getAdjacentWithDirection(c, CASE_BOTTOMRIGHT),
                                getAdjacentWithDirection(c, CASE_BOTTOM) , getAdjacentWithDirection(c, CASE_BOTTOMLEFT),
                                getAdjacentWithDirection(c, CASE_LEFT), getAdjacentWithDirection(c, CASE_TOPLEFT)};
        }

        public Case getAdjacentWithDirection(Case c, Vector2 dir)
        {
            return getCase((char)(c.Column + dir.X), (int)(c.Row + dir.Y));
        }

        public int getOtherPlayer()
        {
            return playerTurn == PLAYER_BLACK ? PLAYER_WHITE : PLAYER_BLACK;
        }

        public void switchPlayer()
        {
            playerTurn = getOtherPlayer();
            setPlayableMoves();
        }

        public int getNbOwnedCases(int player)
        {
            int tmp = 0;
            foreach (Case c in board)
            {
                if (c.Owner != null && c.Owner.PlayerColor == player)
                {
                    tmp++;
                }
            }
            return tmp;
        }

        private int CharPosToInt(char pos)
        {
            return ((int)pos) - 97; 
        }

        private List<Case> getCasesToBeReturned(Case c)
        {
            List<Case> toReturn = new List<Case>();
            Case[] adjacentCase = getAdjacent(c);
            int otherPlayer = getOtherPlayer();
            foreach (Case cc in adjacentCase)
            {
                if (cc != null && cc.Owner != null)
                {
                    if (cc.Owner.PlayerColor == otherPlayer)
                    {
                        List<Case> dirCases = new List<Case>();
                        Vector2 direction = new Vector2(cc.Column - c.Column, cc.Row - c.Row);
                        dirCases.Add(cc);
                        Case nextCase = getAdjacentWithDirection(cc, direction);
                        while (nextCase != null && nextCase.Owner != null)
                        {
                            if (nextCase.Owner.PlayerColor == playerTurn || nextCase.Owner == null)
                            {
                                break;
                            }
                            dirCases.Add(nextCase);
                            nextCase = getAdjacentWithDirection(nextCase, direction);
                        }
                        if (nextCase != null && nextCase.Owner != null && nextCase.Owner.PlayerColor == playerTurn)
                        {
                            toReturn.AddRange(dirCases);
                        }
                    }
                }
            }
            return toReturn;
        }

        public bool playMoveCustom(char col, int row)
        {
            Case selectedCase = getCase(col, row);

            if (selectedCase.Owner == null)
            {
                if (playerTurn == PLAYER_BLACK)
                {
                    selectedCase.Owner = black;
                    foreach (Case c in getCasesToBeReturned(selectedCase))
                    {
                        c.Owner = black;
                    }
                }
                else
                {
                    selectedCase.Owner = white;
                    foreach (Case c in getCasesToBeReturned(selectedCase))
                    {
                        c.Owner = white;
                    }
                }
            }
            setPlayableMoves();
            return selectedCase.Owner != null;
        }

        public int getTour()
        {
            return (GetWhiteScore() + GetBlackScore()) - 4;
        }

        public void resetBoard()
        {
            board = new List<Case>();

            for (char i = 'a'; i <= 'h'; i++)
            {
                for (int j = 1; j <= 8; j++)
                {
                    board.Add(new Case(i, j));
                }
            }
        }

        //Alpha-Beta final function
        public bool IsGameOver(int actualPlayer)
        {
            playerTurn = PLAYER_BLACK;
            setPlayableMoves();

            int nbPos = 0;
            foreach (bool isPlayable in playableMoves.Values)
            {
                if (isPlayable)
                {
                    nbPos++;
                }
            }

            if (nbPos != 0)
            {
                playerTurn = actualPlayer;
                return false;
            }

            playerTurn = PLAYER_WHITE;
            setPlayableMoves();

            nbPos = 0;
            foreach (bool isPlayable in playableMoves.Values)
            {
                if (isPlayable)
                {
                    nbPos++;
                }
            }

            if (nbPos != 0)
            {
                playerTurn = actualPlayer;
                return false;
            }
            playerTurn = actualPlayer;
            return true;
        }

        public List<Case> OwnedCases()
        {
            List<Case> owned = new List<Case>();
            foreach (Case c in board)
            {
                if (c.Owner != null && c.Owner.PlayerColor == playerTurn)
                {
                    owned.Add(c);
                }
            }
            return owned;
        }


        /************************************************
         *                                              * 
         *        ALPHA-BETA SPECIFIC FUNCTIONS         *
         *                                              *
         ************************************************/


        //C# passe par référence, nous avons besoin de fonctions de clonage...        

        private void SwitchWorkingBoard(List<Case> board)
        {
            this.board = CloneBoard(board);
        }

        private void SwitchPlMvDict(Dictionary<Case, bool> dict)
        {
            this.playableMoves = ClonePMoves(dict);
        }

        private List<Case> CloneBoard(List<Case> b)
        {
            List<Case> cloned = new List<Case>(b.Count);
            b.ForEach((item) =>
            {
                cloned.Add((Case)item.Clone());
            });
            return cloned;
        }

        private Dictionary<Case, bool> ClonePMoves(Dictionary<Case, bool> pm)
        {
            Dictionary<Case, bool> cloned = new Dictionary<Case, bool>();
            foreach (KeyValuePair<Case, bool> pair in pm)
            {
                cloned.Add((Case)pair.Key.Clone(), pair.Value);
            }

            return cloned;
        }


        // Fonction alpha beta
        private Tuple<int, Case> AlphaBeta(int depth, int minOrMax, int parentVal)
        {
            //Sauvegarde du plateau et des coups jouables, afin de pouvoir remettre le jeu dans l'état initial après les différentes récursions
            List<Case> workingBoard = CloneBoard(this.board);
            Dictionary<Case, bool> workingPlayableMoves = ClonePMoves(this.playableMoves);

            int actualPlayer = playerTurn;
            if(depth == 0 || IsGameOver(playerTurn))
            {
                return new Tuple<int, Case>(Evaluate(minOrMax), null);
            }
            int optVal = minOrMax * int.MinValue;
            Case optOp = null;

            //Recherche du meilleur coup
            foreach(Case c in workingPlayableMoves.Keys)
            {
                if (workingPlayableMoves[c])
                {
                    playMoveCustom(c.Column, c.Row);
                    switchPlayer();
                    Tuple<int, Case> valDummy = AlphaBeta(depth - 1, -minOrMax, optVal);
                    if(valDummy.Item1 * minOrMax > optVal * minOrMax)
                    {
                        optVal = valDummy.Item1;
                        optOp = c;
                        if(optVal * minOrMax > parentVal * minOrMax)
                        {
                            break;
                        }
                    }
                }
            }

            //Une fois que le meilleur coup a été trouvé, remise du jeu dans l'état initial
            SwitchWorkingBoard(workingBoard);
            SwitchPlMvDict(workingPlayableMoves);
            workingBoard = null;
            workingPlayableMoves = null;
            return new Tuple<int, Case>(optVal, optOp);
        }


        // Fonction d'évaluation
        private int Evaluate(int minOrMax)
        {
            int score = 0;
            int nbPos = 0;
            setPlayableMoves();

            nbPos = 0;
            foreach (bool isPlayable in playableMoves.Values)
            {
                if (isPlayable)
                {
                    nbPos++;
                }
            }

            int tour = getTour();

            //Calcul du score total
            foreach (Case c in OwnedCases())
            {
                if(tour < 12) // Early game (Optimisation selon le nombre de cases prises)
                {
                    score = nbPos * minOrMax;
                    break;
                } else if(tour < 28) //Normal game (Jeu en fonction du tableau de valeur des cases, ainsi qu'un facteur donné)
                {
                    score += (BASE_SCORES[CharPosToInt(c.Column), c.Row - 1] * VH_FACTOR[CharPosToInt(c.Column)] * VH_FACTOR[c.Row - 1] * DIAG_FACTOR_1[CharPosToInt(c.Column), c.Row - 1] * DIAG_FACTOR_2[CharPosToInt(c.Column), c.Row - 1] * minOrMax);
                } else // Late game (Limite le nombre de cases laissées à l'autre joueur)
                {
                    score += getNbOwnedCases(playerTurn) * BASE_SCORES[CharPosToInt(c.Column), c.Row - 1];
                }
                    
                
            }
            
            return score;
        }


    }


}
