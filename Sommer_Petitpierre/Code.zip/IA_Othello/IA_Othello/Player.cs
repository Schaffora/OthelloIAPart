﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OthelloIA2
{
    public class Player
    {
        private bool isBlack;

        public int PlayerColor
        {
            get
            {
                if (isBlack)
                {
                    return OthelloBoard.PLAYER_BLACK;
                }
                else
                {
                    return OthelloBoard.PLAYER_WHITE;
                }
            }
        }

        public Player(bool isBlack)
        {
            this.isBlack = isBlack;
        }
    }
}
